#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# license removed for brevity
import rospy
from std_msgs.msg import String

from sensor_msgs.msg import PointCloud2
from sensor_msgs.msg import PointField
import numpy as np
import time
from std_msgs.msg import Header
from sensor_msgs import point_cloud2

import numpy as np
 
from sensor_msgs.msg import PointField
from sensor_msgs.msg import PointCloud2


def callback(data):
    #rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data)
    point_0 = data.fields
    print(point_0)

def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber('/oslidar/points', PointCloud2, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()



