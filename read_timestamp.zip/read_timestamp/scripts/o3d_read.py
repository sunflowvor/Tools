#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import open3d as o3d
import numpy as np

path = "/home/ivan/Downloads/test/1656069340.805779000.pcd"
pcd_file = o3d.io.read_point_cloud(path, format="pcd")
pcd_arr = np.asarray(pcd_file.points)
print(pcd_arr.shape)
